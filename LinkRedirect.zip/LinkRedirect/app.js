var express = require('express');
var app = express();
var path = require('path');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var config = require('./config');
var base58 = require('./base58.js');

// grab the url model
var Url = require('./models/url');

mongoose.connect('mongodb://' + config.db.host + '/' + config.db.name);

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

/*app.get('/', function(req, res){
  //res.sendFile(path.join(__dirname, 'views/index.html'));
  console.log("Hey");
  res.send({'HEY': 'HEY'});
});*/

app.get('/:encoded_id', function(req, res){

  var base58Id = req.params.encoded_id;

  var id = base58.decode(base58Id);

  // check if url already exists in database
  Url.findOne({_id: id}, function (err, doc){
    //console.log("in get encoded",doc.long_url);
    if (doc) {
      //res.send(doc.long_url);
      res.redirect(doc.long_url);
    } else {
      res.redirect(config.webhost);
      console.log("Error in mapping short url to original url");
    }
  });

});

var server = app.listen(3000, function(){
  console.log('Server listening on port 3000');
});
